# s1270147_learn
This is submission for Exercise 14.
